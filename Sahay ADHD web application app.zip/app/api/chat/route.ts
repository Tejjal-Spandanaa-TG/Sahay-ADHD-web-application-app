import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { message } = await request.json()

    const aiResponse = await generateAIResponse(message)

    return NextResponse.json({
      response: aiResponse,
      timestamp: new Date().toISOString(),
    })
  } catch (error) {
    console.error("Chat API error:", error)
    return NextResponse.json({ error: "Failed to generate response" }, { status: 500 })
  }
}

async function generateAIResponse(userMessage: string): Promise<string> {
  const message = userMessage.toLowerCase()

  // ADHD-specific responses based on common concerns
  if (message.includes("overwhelmed") || message.includes("stressed")) {
    return "I understand feeling overwhelmed can be really challenging with ADHD. Try the 5-4-3-2-1 grounding technique: name 5 things you can see, 4 you can touch, 3 you can hear, 2 you can smell, and 1 you can taste. This can help bring you back to the present moment. Would you like to talk about what's making you feel overwhelmed?"
  }

  if (message.includes("focus") || message.includes("concentration") || message.includes("attention")) {
    return "Focus challenges are one of the most common ADHD experiences. Some strategies that help many people include: breaking tasks into smaller chunks, using timers (like the Pomodoro technique), removing distractions, and finding your optimal environment. What kind of tasks are you having trouble focusing on?"
  }

  if (message.includes("time") || message.includes("schedule") || message.includes("late")) {
    return "Time management with ADHD can feel like trying to catch water with your hands! Some helpful approaches include: using visual schedules, setting multiple alarms, time-blocking your day, and building in buffer time. The key is finding what works for your brain. What time-related challenges are you facing most?"
  }

  if (message.includes("medication") || message.includes("meds")) {
    return "Medication questions are really important to discuss with your healthcare provider, as everyone's needs are different. If you're having concerns about your current medication or considering starting medication, I'd encourage you to write down your questions and symptoms to discuss with your doctor. How are you feeling about your current treatment approach?"
  }

  if (message.includes("symptom") || message.includes("diagnosis")) {
    return "Understanding your ADHD symptoms is a great step in your journey. Everyone experiences ADHD differently - some struggle more with attention, others with hyperactivity or impulsivity, and many with a combination. Have you tried our symptom checker? It might help you identify patterns to discuss with a healthcare professional."
  }

  if (message.includes("work") || message.includes("job") || message.includes("career")) {
    return "ADHD can present unique challenges in the workplace, but also unique strengths! Many people with ADHD are creative, innovative, and great at thinking outside the box. Workplace accommodations, clear communication with supervisors, and finding roles that match your strengths can make a big difference. What aspects of work are you finding most challenging?"
  }

  if (message.includes("relationship") || message.includes("family") || message.includes("friend")) {
    return "ADHD can impact relationships, but understanding and communication can help tremendously. It's important for both you and your loved ones to understand how ADHD affects you. Many people find it helpful to share resources about ADHD with family and friends. Are there specific relationship challenges you'd like to talk about?"
  }

  if (message.includes("sad") || message.includes("depressed") || message.includes("down")) {
    return "I'm sorry you're feeling this way. It's not uncommon for people with ADHD to also experience depression or anxiety. These feelings are valid and treatable. If you're having persistent feelings of sadness, please consider reaching out to a mental health professional. In the meantime, small self-care steps like getting sunlight, gentle movement, or connecting with supportive people can help. Are you getting support for these feelings?"
  }

  if (message.includes("anxious") || message.includes("anxiety") || message.includes("worry")) {
    return "Anxiety often goes hand-in-hand with ADHD, and it's completely understandable. The uncertainty and challenges that come with ADHD can fuel anxious thoughts. Breathing exercises, mindfulness, and grounding techniques can provide immediate relief. For longer-term support, therapy and sometimes medication can be very helpful. What tends to trigger your anxiety most?"
  }

  // Positive/encouraging messages
  if (message.includes("thank") || message.includes("help")) {
    return "You're so welcome! I'm here to support you on your ADHD journey. Remember, seeking understanding and support shows real strength and self-awareness. You're taking positive steps by being here and asking questions."
  }

  if (message.includes("good") || message.includes("better") || message.includes("progress")) {
    return "That's wonderful to hear! Celebrating progress, no matter how small, is so important with ADHD. Your brain works differently, and recognizing your wins helps build confidence and motivation. What's been working well for you lately?"
  }

  // Default supportive responses
  const defaultResponses = [
    "Thank you for sharing that with me. ADHD affects everyone differently, and your experiences are completely valid. What would be most helpful to talk about right now?",
    "I hear you, and what you're going through sounds really challenging. Many people with ADHD face similar struggles, and you're not alone in this. Can you tell me more about what's been on your mind?",
    "That's a really thoughtful observation about yourself. Self-awareness is such an important part of understanding and managing ADHD. How long have you been noticing this pattern?",
    "It sounds like you're being really mindful about your ADHD experience, which is fantastic. Understanding your patterns and triggers is a powerful tool. What strategies have you tried so far?",
    "I appreciate you opening up about this. ADHD can feel overwhelming sometimes, but remember that your brain also has unique strengths and capabilities. What aspects of ADHD do you find most challenging right now?",
  ]

  return defaultResponses[Math.floor(Math.random() * defaultResponses.length)]
}
