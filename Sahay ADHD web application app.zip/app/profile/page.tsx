"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Textarea } from "@/components/ui/textarea"
import { Navigation } from "@/components/navigation"
import { User, Save, Bell, Shield, Palette, Moon, Sun, Volume2, VolumeX } from "lucide-react"
import { cn } from "@/lib/utils"
import { useTheme } from "@/components/theme-provider"

interface UserProfile {
  name: string
  email: string
  bio: string
  notifications: {
    journalReminders: boolean
    symptomCheckReminders: boolean
    dailyTips: boolean
    emailUpdates: boolean
  }
  preferences: {
    soundEffects: boolean
    reducedMotion: boolean
    fontSize: string
  }
}

const defaultProfile: UserProfile = {
  name: "",
  email: "",
  bio: "",
  notifications: {
    journalReminders: true,
    symptomCheckReminders: true,
    dailyTips: false,
    emailUpdates: false,
  },
  preferences: {
    soundEffects: true,
    reducedMotion: false,
    fontSize: "medium",
  },
}

export default function ProfilePage() {
  const [profile, setProfile] = useState<UserProfile>(defaultProfile)
  const [hasChanges, setHasChanges] = useState(false)
  const [isSaving, setIsSaving] = useState(false)
  const { theme, toggleTheme } = useTheme()

  // Load profile from localStorage on component mount
  useEffect(() => {
    const savedProfile = localStorage.getItem("adhd-user-profile")
    if (savedProfile) {
      setProfile(JSON.parse(savedProfile))
    }
  }, [])

  // Track changes
  useEffect(() => {
    const savedProfile = localStorage.getItem("adhd-user-profile")
    const currentProfileString = JSON.stringify(profile)
    const savedProfileString = savedProfile || JSON.stringify(defaultProfile)
    setHasChanges(currentProfileString !== savedProfileString)
  }, [profile])

  const handleSave = async () => {
    setIsSaving(true)

    // Simulate save delay
    await new Promise((resolve) => setTimeout(resolve, 1000))

    localStorage.setItem("adhd-user-profile", JSON.stringify(profile))
    setHasChanges(false)
    setIsSaving(false)
  }

  const updateProfile = (updates: Partial<UserProfile>) => {
    setProfile((prev) => ({ ...prev, ...updates }))
  }

  const updateNotifications = (key: keyof UserProfile["notifications"], value: boolean) => {
    setProfile((prev) => ({
      ...prev,
      notifications: { ...prev.notifications, [key]: value },
    }))
  }

  const updatePreferences = (key: keyof UserProfile["preferences"], value: any) => {
    setProfile((prev) => ({
      ...prev,
      preferences: { ...prev.preferences, [key]: value },
    }))
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-card/30 to-secondary/20">
      <Navigation />

      <main className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="text-center mb-8">
            <div className="h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
              <User className="h-8 w-8 text-primary" />
            </div>
            <h1 className="text-3xl font-bold mb-2">Your Profile</h1>
            <p className="text-muted-foreground text-pretty">
              Customize your experience and manage your account settings
            </p>
          </div>

          <div className="grid lg:grid-cols-3 gap-6">
            {/* Basic Information */}
            <div className="lg:col-span-2 space-y-6">
              <Card className="border-primary/20">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <User className="h-5 w-5" />
                    <span>Basic Information</span>
                  </CardTitle>
                  <CardDescription>Update your personal details</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="name">Full Name</Label>
                      <Input
                        id="name"
                        value={profile.name}
                        onChange={(e) => updateProfile({ name: e.target.value })}
                        placeholder="Enter your name"
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label htmlFor="email">Email Address</Label>
                      <Input
                        id="email"
                        type="email"
                        value={profile.email}
                        onChange={(e) => updateProfile({ email: e.target.value })}
                        placeholder="Enter your email"
                        className="mt-1"
                      />
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="bio">About You (Optional)</Label>
                    <Textarea
                      id="bio"
                      value={profile.bio}
                      onChange={(e) => updateProfile({ bio: e.target.value })}
                      placeholder="Tell us a bit about yourself and your ADHD journey..."
                      className="mt-1 min-h-[100px]"
                      maxLength={500}
                    />
                    <div className="text-xs text-muted-foreground mt-1 text-right">
                      {profile.bio.length}/500 characters
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Notifications */}
              <Card className="border-primary/20">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Bell className="h-5 w-5" />
                    <span>Notifications</span>
                  </CardTitle>
                  <CardDescription>Choose what notifications you'd like to receive</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="journal-reminders" className="font-medium">
                        Journal Reminders
                      </Label>
                      <p className="text-sm text-muted-foreground">Gentle reminders to write in your journal</p>
                    </div>
                    <Switch
                      id="journal-reminders"
                      checked={profile.notifications.journalReminders}
                      onCheckedChange={(checked) => updateNotifications("journalReminders", checked)}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="symptom-reminders" className="font-medium">
                        Symptom Check Reminders
                      </Label>
                      <p className="text-sm text-muted-foreground">Weekly reminders to track your symptoms</p>
                    </div>
                    <Switch
                      id="symptom-reminders"
                      checked={profile.notifications.symptomCheckReminders}
                      onCheckedChange={(checked) => updateNotifications("symptomCheckReminders", checked)}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="daily-tips" className="font-medium">
                        Daily ADHD Tips
                      </Label>
                      <p className="text-sm text-muted-foreground">Helpful tips and strategies for managing ADHD</p>
                    </div>
                    <Switch
                      id="daily-tips"
                      checked={profile.notifications.dailyTips}
                      onCheckedChange={(checked) => updateNotifications("dailyTips", checked)}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="email-updates" className="font-medium">
                        Email Updates
                      </Label>
                      <p className="text-sm text-muted-foreground">
                        Occasional updates about new features and resources
                      </p>
                    </div>
                    <Switch
                      id="email-updates"
                      checked={profile.notifications.emailUpdates}
                      onCheckedChange={(checked) => updateNotifications("emailUpdates", checked)}
                    />
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Preferences Sidebar */}
            <div className="space-y-6">
              <Card className="border-primary/20">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Palette className="h-5 w-5" />
                    <span>Preferences</span>
                  </CardTitle>
                  <CardDescription>Customize your app experience</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      {theme === "dark" ? <Moon className="h-4 w-4" /> : <Sun className="h-4 w-4" />}
                      <Label htmlFor="dark-mode" className="font-medium">
                        Dark Mode
                      </Label>
                    </div>
                    <Switch id="dark-mode" checked={theme === "dark"} onCheckedChange={toggleTheme} />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      {profile.preferences.soundEffects ? (
                        <Volume2 className="h-4 w-4" />
                      ) : (
                        <VolumeX className="h-4 w-4" />
                      )}
                      <Label htmlFor="sound-effects" className="font-medium">
                        Sound Effects
                      </Label>
                    </div>
                    <Switch
                      id="sound-effects"
                      checked={profile.preferences.soundEffects}
                      onCheckedChange={(checked) => updatePreferences("soundEffects", checked)}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="reduced-motion" className="font-medium">
                        Reduced Motion
                      </Label>
                      <p className="text-xs text-muted-foreground">Minimize animations</p>
                    </div>
                    <Switch
                      id="reduced-motion"
                      checked={profile.preferences.reducedMotion}
                      onCheckedChange={(checked) => updatePreferences("reducedMotion", checked)}
                    />
                  </div>

                  <div>
                    <Label htmlFor="font-size" className="font-medium">
                      Font Size
                    </Label>
                    <select
                      id="font-size"
                      value={profile.preferences.fontSize}
                      onChange={(e) => updatePreferences("fontSize", e.target.value)}
                      className="w-full mt-1 px-3 py-2 border border-input rounded-md bg-background text-sm"
                    >
                      <option value="small">Small</option>
                      <option value="medium">Medium</option>
                      <option value="large">Large</option>
                    </select>
                  </div>
                </CardContent>
              </Card>

              {/* Privacy */}
              <Card className="border-primary/20">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Shield className="h-5 w-5" />
                    <span>Privacy</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    Your data is stored locally on your device and never shared with third parties.
                  </p>
                  <Button variant="outline" size="sm" className="w-full bg-transparent">
                    Export My Data
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="w-full text-destructive hover:text-destructive bg-transparent"
                  >
                    Delete All Data
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Save Button */}
          <div className="mt-8 flex justify-center">
            <Button
              onClick={handleSave}
              disabled={!hasChanges || isSaving}
              size="lg"
              className={cn("transition-all duration-200", hasChanges && "animate-pulse")}
            >
              <Save className="h-4 w-4 mr-2" />
              {isSaving ? "Saving..." : hasChanges ? "Save Changes" : "All Changes Saved"}
            </Button>
          </div>
        </div>
      </main>
    </div>
  )
}
