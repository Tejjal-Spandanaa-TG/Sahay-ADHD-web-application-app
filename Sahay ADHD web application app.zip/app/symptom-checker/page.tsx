"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Navigation } from "@/components/navigation"
import { ArrowLeft, ArrowRight, CheckCircle, ClipboardList } from "lucide-react"
import Link from "next/link"

const questions = [
  {
    id: 1,
    question: "How often do you have trouble wrapping up the final details of a project?",
    options: [
      { value: "0", label: "Never" },
      { value: "1", label: "Rarely" },
      { value: "2", label: "Sometimes" },
      { value: "3", label: "Often" },
      { value: "4", label: "Very Often" },
    ],
  },
  {
    id: 2,
    question:
      "How often do you have difficulty getting things in order when you have to do a task that requires organization?",
    options: [
      { value: "0", label: "Never" },
      { value: "1", label: "Rarely" },
      { value: "2", label: "Sometimes" },
      { value: "3", label: "Often" },
      { value: "4", label: "Very Often" },
    ],
  },
  {
    id: 3,
    question: "How often do you have problems remembering appointments or obligations?",
    options: [
      { value: "0", label: "Never" },
      { value: "1", label: "Rarely" },
      { value: "2", label: "Sometimes" },
      { value: "3", label: "Often" },
      { value: "4", label: "Very Often" },
    ],
  },
  {
    id: 4,
    question: "How often do you avoid or delay getting started on tasks that require a lot of thought?",
    options: [
      { value: "0", label: "Never" },
      { value: "1", label: "Rarely" },
      { value: "2", label: "Sometimes" },
      { value: "3", label: "Often" },
      { value: "4", label: "Very Often" },
    ],
  },
  {
    id: 5,
    question: "How often do you fidget or squirm with your hands or feet when you have to sit down for a long time?",
    options: [
      { value: "0", label: "Never" },
      { value: "1", label: "Rarely" },
      { value: "2", label: "Sometimes" },
      { value: "3", label: "Often" },
      { value: "4", label: "Very Often" },
    ],
  },
  {
    id: 6,
    question: "How often do you feel overly active and compelled to do things, like you were driven by a motor?",
    options: [
      { value: "0", label: "Never" },
      { value: "1", label: "Rarely" },
      { value: "2", label: "Sometimes" },
      { value: "3", label: "Often" },
      { value: "4", label: "Very Often" },
    ],
  },
]

export default function SymptomCheckerPage() {
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [answers, setAnswers] = useState<Record<number, string>>({})
  const [isComplete, setIsComplete] = useState(false)

  const progress = ((currentQuestion + 1) / questions.length) * 100
  const totalScore = Object.values(answers).reduce((sum, value) => sum + Number.parseInt(value), 0)

  const handleAnswer = (value: string) => {
    setAnswers((prev) => ({
      ...prev,
      [questions[currentQuestion].id]: value,
    }))
  }

  const handleNext = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion((prev) => prev + 1)
    }
  }

  const handlePrevious = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion((prev) => prev - 1)
    }
  }

  const handleSubmit = () => {
    setIsComplete(true)
  }

  const getResultMessage = (score: number) => {
    if (score <= 8) {
      return {
        title: "Low Likelihood",
        message: "Your responses suggest a low likelihood of ADHD symptoms. However, this is just a screening tool.",
        color: "text-green-600",
      }
    } else if (score <= 16) {
      return {
        title: "Moderate Likelihood",
        message:
          "Your responses suggest some ADHD symptoms may be present. Consider discussing with a healthcare professional.",
        color: "text-yellow-600",
      }
    } else {
      return {
        title: "Higher Likelihood",
        message:
          "Your responses suggest ADHD symptoms may be significantly impacting your life. We recommend consulting with a healthcare professional.",
        color: "text-orange-600",
      }
    }
  }

  if (isComplete) {
    const result = getResultMessage(totalScore)

    return (
      <div className="min-h-screen bg-gradient-to-br from-background via-card/30 to-secondary/20">
        <Navigation />

        <main className="container mx-auto px-4 py-12">
          <div className="max-w-2xl mx-auto">
            <Card className="border-primary/20 shadow-lg">
              <CardHeader className="text-center">
                <div className="h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                  <CheckCircle className="h-8 w-8 text-primary" />
                </div>
                <CardTitle className="text-2xl mb-2">Assessment Complete</CardTitle>
                <CardDescription>Thank you for taking the time to complete this screening</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="text-center">
                  <div className="text-3xl font-bold mb-2">{totalScore}/24</div>
                  <div className={`text-lg font-semibold ${result.color}`}>{result.title}</div>
                </div>

                <div className="bg-muted/50 p-4 rounded-lg">
                  <p className="text-sm leading-relaxed">{result.message}</p>
                </div>

                <div className="bg-blue-50 border border-blue-200 p-4 rounded-lg">
                  <p className="text-sm text-blue-800 leading-relaxed">
                    <strong>Important:</strong> This is a screening tool and not a diagnostic test. Only a qualified
                    healthcare professional can diagnose ADHD. If you have concerns, please consult with your doctor or
                    a mental health professional.
                  </p>
                </div>

                <div className="flex flex-col sm:flex-row gap-3">
                  <Button
                    onClick={() => {
                      setCurrentQuestion(0)
                      setAnswers({})
                      setIsComplete(false)
                    }}
                    variant="outline"
                    className="flex-1"
                  >
                    Take Again
                  </Button>
                  <Button asChild className="flex-1">
                    <Link
                      href={`/support-plan?score=${totalScore}&level=${
                        totalScore <= 8 ? "low" : totalScore <= 16 ? "moderate" : "high"
                      }`}
                    >
                      Get Your Support Plan
                    </Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-card/30 to-secondary/20">
      <Navigation />

      <main className="container mx-auto px-4 py-12">
        <div className="max-w-2xl mx-auto">
          {/* Header */}
          <div className="text-center mb-8">
            <div className="h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
              <ClipboardList className="h-8 w-8 text-primary" />
            </div>
            <h1 className="text-3xl font-bold mb-2">ADHD Symptom Checker</h1>
            <p className="text-muted-foreground text-pretty">
              This brief screening can help identify potential ADHD symptoms. Take your time and answer honestly.
            </p>
          </div>

          {/* Progress */}
          <div className="mb-8">
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm text-muted-foreground">
                Question {currentQuestion + 1} of {questions.length}
              </span>
              <span className="text-sm text-muted-foreground">{Math.round(progress)}% Complete</span>
            </div>
            <Progress value={progress} className="h-2" />
          </div>

          {/* Question Card */}
          <Card className="mb-8 border-primary/20 shadow-lg">
            <CardHeader>
              <CardTitle className="text-lg leading-relaxed text-balance">
                {questions[currentQuestion].question}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <RadioGroup
                value={answers[questions[currentQuestion].id] || ""}
                onValueChange={handleAnswer}
                className="space-y-3"
              >
                {questions[currentQuestion].options.map((option) => (
                  <div
                    key={option.value}
                    className="flex items-center space-x-3 p-3 rounded-lg hover:bg-muted/50 transition-colors"
                  >
                    <RadioGroupItem value={option.value} id={option.value} />
                    <Label htmlFor={option.value} className="flex-1 cursor-pointer text-sm leading-relaxed">
                      {option.label}
                    </Label>
                  </div>
                ))}
              </RadioGroup>
            </CardContent>
          </Card>

          {/* Navigation */}
          <div className="flex justify-between items-center">
            <Button
              variant="outline"
              onClick={handlePrevious}
              disabled={currentQuestion === 0}
              className="flex items-center space-x-2 bg-transparent"
            >
              <ArrowLeft className="h-4 w-4" />
              <span>Previous</span>
            </Button>

            {currentQuestion === questions.length - 1 ? (
              <Button
                onClick={handleSubmit}
                disabled={!answers[questions[currentQuestion].id]}
                className="flex items-center space-x-2"
              >
                <span>Submit Assessment</span>
                <CheckCircle className="h-4 w-4" />
              </Button>
            ) : (
              <Button
                onClick={handleNext}
                disabled={!answers[questions[currentQuestion].id]}
                className="flex items-center space-x-2"
              >
                <span>Next</span>
                <ArrowRight className="h-4 w-4" />
              </Button>
            )}
          </div>

          {/* Help Text */}
          <div className="mt-8 text-center">
            <p className="text-xs text-muted-foreground">
              Need help? Our{" "}
              <a href="/chatbot" className="text-primary hover:underline">
                AI chatbot
              </a>{" "}
              is here to support you.
            </p>
          </div>
        </div>
      </main>
    </div>
  )
}
