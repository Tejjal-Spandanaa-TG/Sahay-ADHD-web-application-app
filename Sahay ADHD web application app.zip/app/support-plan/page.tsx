"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Navigation } from "@/components/navigation"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import Link from "next/link"
import { Heart, Calendar, BookOpen, MessageCircle, Gamepad2, CheckCircle, Clock, Target, Phone } from "lucide-react"

interface SupportPlanProps {
  score?: number
  riskLevel?: "low" | "moderate" | "high"
}

export default function SupportPlanPage({ searchParams }: { searchParams: { score?: string; level?: string } }) {
  const score = searchParams.score ? Number.parseInt(searchParams.score) : 0
  const riskLevel = (searchParams.level as "low" | "moderate" | "high") || "low"

  const [completedTasks, setCompletedTasks] = useState<string[]>([])

  const toggleTask = (taskId: string) => {
    setCompletedTasks((prev) => (prev.includes(taskId) ? prev.filter((id) => id !== taskId) : [...prev, taskId]))
  }

  const getSupportPlan = (level: string) => {
    switch (level) {
      case "high":
        return {
          title: "Comprehensive Support Plan",
          description:
            "Your assessment suggests significant ADHD symptoms. Here's a personalized plan to help you thrive.",
          color: "border-orange-200 bg-orange-50",
          urgentActions: [
            {
              id: "professional",
              title: "Schedule Professional Consultation",
              description: "Connect with an ADHD specialist",
              urgent: true,
            },
            {
              id: "crisis",
              title: "Know Your Crisis Resources",
              description: "Save important helpline numbers",
              urgent: true,
            },
          ],
          dailyTasks: [
            {
              id: "morning",
              title: "Morning Routine Check-in",
              description: "Start your day with intention",
              time: "5 min",
            },
            {
              id: "breathing",
              title: "Mindful Breathing",
              description: "Calm your mind with guided breathing",
              time: "3 min",
            },
            {
              id: "journal",
              title: "Evening Reflection",
              description: "Process your day in your private journal",
              time: "10 min",
            },
          ],
          weeklyGoals: [
            {
              id: "chat",
              title: "AI Support Sessions",
              description: "Have 3 meaningful conversations with our chatbot",
              target: "3x/week",
            },
            { id: "games", title: "Focus Training", description: "Play attention-building games", target: "4x/week" },
            {
              id: "tracking",
              title: "Symptom Monitoring",
              description: "Track your symptoms and patterns",
              target: "Daily",
            },
          ],
        }
      case "moderate":
        return {
          title: "Balanced Support Plan",
          description: "Your assessment shows some ADHD symptoms. Let's build healthy habits together.",
          color: "border-yellow-200 bg-yellow-50",
          urgentActions: [
            { id: "learn", title: "Learn About ADHD", description: "Understand your symptoms better", urgent: false },
            {
              id: "routine",
              title: "Establish Daily Routines",
              description: "Create structure in your day",
              urgent: false,
            },
          ],
          dailyTasks: [
            { id: "check", title: "Quick Mood Check", description: "How are you feeling today?", time: "2 min" },
            { id: "focus", title: "Focus Game", description: "Train your attention with fun games", time: "10 min" },
            { id: "reflect", title: "Daily Reflection", description: "Journal about your experiences", time: "5 min" },
          ],
          weeklyGoals: [
            { id: "chat", title: "AI Conversations", description: "Chat with our supportive AI", target: "2x/week" },
            { id: "games", title: "Cognitive Training", description: "Play brain-training games", target: "3x/week" },
            { id: "habits", title: "Habit Building", description: "Work on one new positive habit", target: "Daily" },
          ],
        }
      default:
        return {
          title: "Wellness Maintenance Plan",
          description: "Great job! Let's maintain your mental wellness with preventive care.",
          color: "border-green-200 bg-green-50",
          urgentActions: [
            {
              id: "maintain",
              title: "Maintain Current Wellness",
              description: "Keep up your good habits",
              urgent: false,
            },
            { id: "support", title: "Be a Peer Support", description: "Help others in the community", urgent: false },
          ],
          dailyTasks: [
            {
              id: "gratitude",
              title: "Gratitude Practice",
              description: "Note three things you're grateful for",
              time: "3 min",
            },
            { id: "mindful", title: "Mindful Moment", description: "Take a mindful break", time: "5 min" },
            {
              id: "connect",
              title: "Connect with Others",
              description: "Reach out to someone you care about",
              time: "10 min",
            },
          ],
          weeklyGoals: [
            { id: "explore", title: "Explore New Tools", description: "Try new features in Sahay", target: "1x/week" },
            {
              id: "help",
              title: "Help Others",
              description: "Share your experience to help others",
              target: "1x/week",
            },
            { id: "growth", title: "Personal Growth", description: "Work on personal development", target: "Ongoing" },
          ],
        }
    }
  }

  const plan = getSupportPlan(riskLevel)
  const progressPercentage = (completedTasks.length / (plan.dailyTasks.length + plan.weeklyGoals.length)) * 100

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-card/30 to-secondary/20">
      <Navigation />

      <main className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="text-center mb-8">
            <div className="h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
              <Heart className="h-8 w-8 text-primary" />
            </div>
            <h1 className="text-3xl font-bold mb-2">{plan.title}</h1>
            <p className="text-muted-foreground text-pretty max-w-2xl mx-auto">{plan.description}</p>
          </div>

          {/* Progress Overview */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Target className="h-5 w-5" />
                <span>Your Progress Today</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-muted-foreground">Completed Tasks</span>
                <span className="text-sm font-medium">
                  {completedTasks.length} / {plan.dailyTasks.length + plan.weeklyGoals.length}
                </span>
              </div>
              <Progress value={progressPercentage} className="h-2" />
            </CardContent>
          </Card>

          {/* Crisis Resources (for high risk) */}
          {riskLevel === "high" && (
            <Card className="mb-8 border-red-200 bg-red-50">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2 text-red-800">
                  <Phone className="h-5 w-5" />
                  <span>Immediate Support Resources</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="p-3 bg-white rounded-lg border">
                    <h4 className="font-semibold text-sm">Crisis Helpline</h4>
                    <p className="text-sm text-muted-foreground">24/7 Mental Health Support</p>
                    <p className="font-mono text-lg">1-800-273-8255</p>
                  </div>
                  <div className="p-3 bg-white rounded-lg border">
                    <h4 className="font-semibold text-sm">ADHD Support</h4>
                    <p className="text-sm text-muted-foreground">Specialized ADHD Resources</p>
                    <p className="font-mono text-lg">1-800-233-4050</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Daily Tasks */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Clock className="h-5 w-5" />
                <span>Daily Wellness Tasks</span>
              </CardTitle>
              <CardDescription>Small steps that make a big difference</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {plan.dailyTasks.map((task) => (
                <div
                  key={task.id}
                  className="flex items-center space-x-3 p-3 rounded-lg border hover:bg-muted/50 transition-colors"
                >
                  <button
                    onClick={() => toggleTask(task.id)}
                    className={`h-5 w-5 rounded border-2 flex items-center justify-center transition-colors ${
                      completedTasks.includes(task.id)
                        ? "bg-primary border-primary text-primary-foreground"
                        : "border-muted-foreground hover:border-primary"
                    }`}
                  >
                    {completedTasks.includes(task.id) && <CheckCircle className="h-3 w-3" />}
                  </button>
                  <div className="flex-1">
                    <h4 className="font-medium">{task.title}</h4>
                    <p className="text-sm text-muted-foreground">{task.description}</p>
                  </div>
                  <Badge variant="secondary">{task.time}</Badge>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Weekly Goals */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Calendar className="h-5 w-5" />
                <span>Weekly Goals</span>
              </CardTitle>
              <CardDescription>Building lasting habits for your wellbeing</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {plan.weeklyGoals.map((goal) => (
                <div
                  key={goal.id}
                  className="flex items-center space-x-3 p-3 rounded-lg border hover:bg-muted/50 transition-colors"
                >
                  <button
                    onClick={() => toggleTask(goal.id)}
                    className={`h-5 w-5 rounded border-2 flex items-center justify-center transition-colors ${
                      completedTasks.includes(goal.id)
                        ? "bg-primary border-primary text-primary-foreground"
                        : "border-muted-foreground hover:border-primary"
                    }`}
                  >
                    {completedTasks.includes(goal.id) && <CheckCircle className="h-3 w-3" />}
                  </button>
                  <div className="flex-1">
                    <h4 className="font-medium">{goal.title}</h4>
                    <p className="text-sm text-muted-foreground">{goal.description}</p>
                  </div>
                  <Badge variant="outline">{goal.target}</Badge>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Quick Actions */}
          <Card>
            <CardHeader>
              <CardTitle>Take Action Now</CardTitle>
              <CardDescription>Start your wellness journey with these tools</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-3 gap-4">
                <Button asChild className="h-auto p-4 flex-col space-y-2">
                  <Link href="/chatbot">
                    <MessageCircle className="h-6 w-6" />
                    <span>Talk to AI Support</span>
                  </Link>
                </Button>
                <Button asChild variant="secondary" className="h-auto p-4 flex-col space-y-2">
                  <Link href="/journal">
                    <BookOpen className="h-6 w-6" />
                    <span>Start Journaling</span>
                  </Link>
                </Button>
                <Button asChild variant="outline" className="h-auto p-4 flex-col space-y-2 bg-transparent">
                  <Link href="/games">
                    <Gamepad2 className="h-6 w-6" />
                    <span>Play Focus Games</span>
                  </Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
