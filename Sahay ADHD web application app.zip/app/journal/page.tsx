"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Navigation } from "@/components/navigation"
import { BookOpen, Save, Calendar, Trash2, Edit3, Plus, Heart } from "lucide-react"
import { cn } from "@/lib/utils"

interface JournalEntry {
  id: string
  content: string
  date: Date
  mood?: string
}

const moodOptions = [
  { value: "great", label: "Great", color: "text-green-600", bg: "bg-green-100" },
  { value: "good", label: "Good", color: "text-blue-600", bg: "bg-blue-100" },
  { value: "okay", label: "Okay", color: "text-yellow-600", bg: "bg-yellow-100" },
  { value: "difficult", label: "Difficult", color: "text-orange-600", bg: "bg-orange-100" },
  { value: "challenging", label: "Challenging", color: "text-red-600", bg: "bg-red-100" },
]

export default function JournalPage() {
  const [entries, setEntries] = useState<JournalEntry[]>([])
  const [currentEntry, setCurrentEntry] = useState("")
  const [selectedMood, setSelectedMood] = useState<string>("")
  const [editingId, setEditingId] = useState<string | null>(null)

  // Load entries from localStorage on component mount
  useEffect(() => {
    const savedEntries = localStorage.getItem("adhd-journal-entries")
    if (savedEntries) {
      const parsedEntries = JSON.parse(savedEntries).map((entry: any) => ({
        ...entry,
        date: new Date(entry.date),
      }))
      setEntries(parsedEntries)
    }
  }, [])

  // Save entries to localStorage whenever entries change
  useEffect(() => {
    if (entries.length > 0) {
      localStorage.setItem("adhd-journal-entries", JSON.stringify(entries))
    }
  }, [entries])

  const handleSaveEntry = () => {
    if (!currentEntry.trim()) return

    const newEntry: JournalEntry = {
      id: editingId || Date.now().toString(),
      content: currentEntry.trim(),
      date: new Date(),
      mood: selectedMood || undefined,
    }

    if (editingId) {
      setEntries((prev) => prev.map((entry) => (entry.id === editingId ? newEntry : entry)))
      setEditingId(null)
    } else {
      setEntries((prev) => [newEntry, ...prev])
    }

    setCurrentEntry("")
    setSelectedMood("")
  }

  const handleEditEntry = (entry: JournalEntry) => {
    setCurrentEntry(entry.content)
    setSelectedMood(entry.mood || "")
    setEditingId(entry.id)
  }

  const handleDeleteEntry = (id: string) => {
    setEntries((prev) => prev.filter((entry) => entry.id !== id))
    const updatedEntries = entries.filter((entry) => entry.id !== id)
    if (updatedEntries.length === 0) {
      localStorage.removeItem("adhd-journal-entries")
    }
  }

  const handleCancelEdit = () => {
    setCurrentEntry("")
    setSelectedMood("")
    setEditingId(null)
  }

  const formatDate = (date: Date) => {
    return date.toLocaleDateString("en-US", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    })
  }

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString("en-US", {
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-card/30 to-secondary/20">
      <Navigation />

      <main className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="text-center mb-8">
            <div className="h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
              <BookOpen className="h-8 w-8 text-primary" />
            </div>
            <h1 className="text-3xl font-bold mb-2">Personal Journal</h1>
            <p className="text-muted-foreground text-pretty">
              A safe space to organize your thoughts, track your journey, and reflect on your experiences
            </p>
          </div>

          {/* New Entry Card */}
          <Card className="mb-8 border-primary/20 shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                {editingId ? <Edit3 className="h-5 w-5" /> : <Plus className="h-5 w-5" />}
                <span>{editingId ? "Edit Entry" : "New Journal Entry"}</span>
              </CardTitle>
              <CardDescription>
                {editingId ? "Update your thoughts and feelings" : "What's on your mind today?"}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Mood Selection */}
              <div>
                <label className="text-sm font-medium mb-2 block">How are you feeling? (optional)</label>
                <div className="flex flex-wrap gap-2">
                  {moodOptions.map((mood) => (
                    <Button
                      key={mood.value}
                      variant={selectedMood === mood.value ? "default" : "outline"}
                      size="sm"
                      onClick={() => setSelectedMood(selectedMood === mood.value ? "" : mood.value)}
                      className={cn(
                        "transition-all duration-200",
                        selectedMood === mood.value && `${mood.bg} ${mood.color} border-current`,
                      )}
                    >
                      <Heart className="h-3 w-3 mr-1" />
                      {mood.label}
                    </Button>
                  ))}
                </div>
              </div>

              {/* Text Area */}
              <div>
                <Textarea
                  value={currentEntry}
                  onChange={(e) => setCurrentEntry(e.target.value)}
                  placeholder="Write about your day, your thoughts, your challenges, or your wins. This is your space..."
                  className="min-h-[120px] resize-none border-primary/20 focus:border-primary"
                  maxLength={2000}
                />
                <div className="text-xs text-muted-foreground mt-1 text-right">
                  {currentEntry.length}/2000 characters
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex justify-between items-center">
                <div className="text-sm text-muted-foreground">
                  {editingId ? "Editing entry" : "Your thoughts are private and secure"}
                </div>
                <div className="flex space-x-2">
                  {editingId && (
                    <Button variant="outline" onClick={handleCancelEdit} size="sm">
                      Cancel
                    </Button>
                  )}
                  <Button
                    onClick={handleSaveEntry}
                    disabled={!currentEntry.trim()}
                    className="flex items-center space-x-2"
                    size="sm"
                  >
                    <Save className="h-4 w-4" />
                    <span>{editingId ? "Update Entry" : "Save Entry"}</span>
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Past Entries */}
          <div>
            <h2 className="text-2xl font-bold mb-6 flex items-center space-x-2">
              <Calendar className="h-6 w-6 text-primary" />
              <span>Your Journal Entries</span>
              <span className="text-sm font-normal text-muted-foreground">({entries.length})</span>
            </h2>

            {entries.length === 0 ? (
              <Card className="text-center py-12 border-dashed border-primary/20">
                <CardContent>
                  <BookOpen className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-semibold mb-2">No entries yet</h3>
                  <p className="text-muted-foreground mb-4">
                    Start your journaling journey by writing your first entry above
                  </p>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-4">
                {entries.map((entry) => {
                  const mood = moodOptions.find((m) => m.value === entry.mood)

                  return (
                    <Card key={entry.id} className="border-primary/10 hover:shadow-md transition-all duration-200">
                      <CardHeader className="pb-3">
                        <div className="flex justify-between items-start">
                          <div className="flex items-center space-x-3">
                            <div>
                              <CardTitle className="text-base">{formatDate(entry.date)}</CardTitle>
                              <CardDescription className="text-sm">
                                {formatTime(entry.date)}
                                {mood && (
                                  <span className={cn("ml-2 px-2 py-1 rounded-full text-xs", mood.bg, mood.color)}>
                                    {mood.label}
                                  </span>
                                )}
                              </CardDescription>
                            </div>
                          </div>
                          <div className="flex space-x-1">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleEditEntry(entry)}
                              className="h-8 w-8 p-0"
                            >
                              <Edit3 className="h-3 w-3" />
                              <span className="sr-only">Edit entry</span>
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleDeleteEntry(entry.id)}
                              className="h-8 w-8 p-0 text-destructive hover:text-destructive"
                            >
                              <Trash2 className="h-3 w-3" />
                              <span className="sr-only">Delete entry</span>
                            </Button>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm leading-relaxed whitespace-pre-wrap">{entry.content}</p>
                      </CardContent>
                    </Card>
                  )
                })}
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  )
}
