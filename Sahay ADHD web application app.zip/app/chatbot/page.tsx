"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Navigation } from "@/components/navigation"
import { MessageCircle, Send, Bot, User, Sparkles } from "lucide-react"
import { cn } from "@/lib/utils"

interface Message {
  id: string
  content: string
  sender: "user" | "ai"
  timestamp: Date
}

const initialMessages: Message[] = [
  {
    id: "1",
    content: "Hello! I'm here to provide support and understanding for your ADHD journey. How are you feeling today?",
    sender: "ai",
    timestamp: new Date(),
  },
]

const sampleResponses = [
  "I understand that can be really challenging. ADHD affects everyone differently, and your experiences are valid.",
  "That sounds frustrating. Many people with ADHD experience similar difficulties. What strategies have you tried before?",
  "It's great that you're being mindful of your symptoms. Self-awareness is an important step in managing ADHD.",
  "Remember to be patient with yourself. ADHD brains work differently, and that's not something to fix - it's something to understand and work with.",
  "Have you considered breaking that task into smaller, more manageable steps? Sometimes that can make things feel less overwhelming.",
  "It's completely normal to have good days and challenging days. What you're experiencing is part of the ADHD experience.",
  "That's a really insightful observation about yourself. Understanding your patterns can help you develop better coping strategies.",
]

export default function ChatbotPage() {
  const [messages, setMessages] = useState<Message[]>(initialMessages)
  const [inputValue, setInputValue] = useState("")
  const [isTyping, setIsTyping] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const handleSendMessage = async () => {
    if (!inputValue.trim()) return

    const userMessage: Message = {
      id: Date.now().toString(),
      content: inputValue,
      sender: "user",
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    const messageContent = inputValue
    setInputValue("")
    setIsTyping(true)

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ message: messageContent }),
      })

      if (!response.ok) {
        throw new Error("Failed to get AI response")
      }

      const data = await response.json()

      const aiResponse: Message = {
        id: (Date.now() + 1).toString(),
        content: data.response,
        sender: "ai",
        timestamp: new Date(),
      }

      setMessages((prev) => [...prev, aiResponse])
    } catch (error) {
      console.error("Error getting AI response:", error)
      // Fallback to sample response if API fails
      const aiResponse: Message = {
        id: (Date.now() + 1).toString(),
        content:
          "I'm sorry, I'm having trouble connecting right now. Please try again in a moment, or consider reaching out to a healthcare professional if you need immediate support.",
        sender: "ai",
        timestamp: new Date(),
      }
      setMessages((prev) => [...prev, aiResponse])
    } finally {
      setIsTyping(false)
    }
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      handleSendMessage()
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-card/30 to-secondary/20">
      <Navigation />

      <main className="container mx-auto px-4 py-6">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="text-center mb-6">
            <div className="h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
              <MessageCircle className="h-8 w-8 text-primary" />
            </div>
            <h1 className="text-3xl font-bold mb-2">ADHD Support Chat</h1>
            <p className="text-muted-foreground text-pretty">
              A safe space to discuss your experiences and get understanding support
            </p>
          </div>

          {/* Chat Container */}
          <Card className="h-[600px] flex flex-col border-primary/20 shadow-lg">
            <CardHeader className="border-b bg-card/50">
              <CardTitle className="flex items-center space-x-2 text-lg">
                <Bot className="h-5 w-5 text-primary" />
                <span>ADHD Support Assistant</span>
                <div className="h-2 w-2 rounded-full bg-green-500 animate-pulse" />
              </CardTitle>
            </CardHeader>

            {/* Messages Area */}
            <CardContent className="flex-1 overflow-y-auto p-4 space-y-4">
              {messages.map((message) => (
                <div
                  key={message.id}
                  className={cn(
                    "flex items-start space-x-3",
                    message.sender === "user" ? "justify-end" : "justify-start",
                  )}
                >
                  {message.sender === "ai" && (
                    <div className="h-8 w-8 rounded-full bg-secondary/20 flex items-center justify-center flex-shrink-0">
                      <Bot className="h-4 w-4 text-secondary" />
                    </div>
                  )}

                  <div
                    className={cn(
                      "max-w-[80%] rounded-2xl px-4 py-3 text-sm leading-relaxed",
                      message.sender === "user"
                        ? "bg-primary text-primary-foreground ml-12"
                        : "bg-card border border-border mr-12",
                    )}
                  >
                    <p>{message.content}</p>
                    <div
                      className={cn(
                        "text-xs mt-2 opacity-70",
                        message.sender === "user" ? "text-primary-foreground/70" : "text-muted-foreground",
                      )}
                    >
                      {message.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                    </div>
                  </div>

                  {message.sender === "user" && (
                    <div className="h-8 w-8 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0">
                      <User className="h-4 w-4 text-primary" />
                    </div>
                  )}
                </div>
              ))}

              {/* Typing Indicator */}
              {isTyping && (
                <div className="flex items-start space-x-3">
                  <div className="h-8 w-8 rounded-full bg-secondary/20 flex items-center justify-center flex-shrink-0">
                    <Bot className="h-4 w-4 text-secondary" />
                  </div>
                  <div className="bg-card border border-border rounded-2xl px-4 py-3 mr-12">
                    <div className="flex space-x-1">
                      <div className="h-2 w-2 bg-muted-foreground rounded-full animate-bounce" />
                      <div
                        className="h-2 w-2 bg-muted-foreground rounded-full animate-bounce"
                        style={{ animationDelay: "0.1s" }}
                      />
                      <div
                        className="h-2 w-2 bg-muted-foreground rounded-full animate-bounce"
                        style={{ animationDelay: "0.2s" }}
                      />
                    </div>
                  </div>
                </div>
              )}

              <div ref={messagesEndRef} />
            </CardContent>

            {/* Input Area */}
            <div className="border-t p-4 bg-card/50">
              <div className="flex space-x-2">
                <Input
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  onKeyPress={handleKeyPress}
                  placeholder="Type your message here..."
                  className="flex-1 rounded-full border-primary/20 focus:border-primary"
                  disabled={isTyping}
                />
                <Button
                  onClick={handleSendMessage}
                  disabled={!inputValue.trim() || isTyping}
                  size="icon"
                  className="rounded-full h-10 w-10 flex-shrink-0"
                >
                  <Send className="h-4 w-4" />
                  <span className="sr-only">Send message</span>
                </Button>
              </div>
              <p className="text-xs text-muted-foreground mt-2 text-center">
                This is a supportive chat experience. For professional help, please consult a healthcare provider.
              </p>
            </div>
          </Card>

          {/* Quick Actions */}
          <div className="mt-6">
            <h3 className="text-sm font-medium text-muted-foreground mb-3 text-center">Quick conversation starters:</h3>
            <div className="flex flex-wrap justify-center gap-2">
              {[
                "I'm feeling overwhelmed today",
                "Help me understand my ADHD symptoms",
                "I'm struggling with focus",
                "How can I manage my time better?",
              ].map((starter) => (
                <Button
                  key={starter}
                  variant="outline"
                  size="sm"
                  onClick={() => setInputValue(starter)}
                  className="text-xs rounded-full border-primary/20 hover:border-primary hover:bg-primary/5"
                >
                  <Sparkles className="h-3 w-3 mr-1" />
                  {starter}
                </Button>
              ))}
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
