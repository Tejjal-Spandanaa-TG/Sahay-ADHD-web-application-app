"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Navigation } from "@/components/navigation"
import { Gamepad2, Clock, Brain, Target, Puzzle, Zap, Star, Play, Lock } from "lucide-react"
import { FocusFlow } from "@/components/games/focus-flow"
import { MemoryGarden } from "@/components/games/memory-garden"
import { CalmColoring } from "@/components/games/calm-coloring"

const games = [
  {
    id: 1,
    title: "Focus Flow",
    description: "A gentle breathing exercise game that helps improve concentration and reduce anxiety",
    difficulty: "Easy",
    duration: "5-10 min",
    category: "Mindfulness",
    icon: Brain,
    color: "bg-blue-100 text-blue-600",
    available: true,
  },
  {
    id: 2,
    title: "Memory Garden",
    description: "Plant and tend to a virtual garden while practicing working memory skills",
    difficulty: "Medium",
    duration: "10-15 min",
    category: "Memory",
    icon: Target,
    color: "bg-green-100 text-green-600",
    available: true,
  },
  {
    id: 3,
    title: "Pattern Puzzle",
    description: "Solve calming pattern puzzles that help with attention to detail and planning",
    difficulty: "Medium",
    duration: "15-20 min",
    category: "Problem Solving",
    icon: Puzzle,
    color: "bg-purple-100 text-purple-600",
    available: false,
  },
  {
    id: 4,
    title: "Reaction Time",
    description: "Fun reaction-based mini-games that help with impulse control and attention",
    difficulty: "Easy",
    duration: "5-10 min",
    category: "Attention",
    icon: Zap,
    color: "bg-yellow-100 text-yellow-600",
    available: false,
  },
  {
    id: 5,
    title: "Calm Coloring",
    description: "Digital coloring book with ADHD-friendly designs for relaxation and focus",
    difficulty: "Easy",
    duration: "10-30 min",
    category: "Creativity",
    icon: Star,
    color: "bg-pink-100 text-pink-600",
    available: true,
  },
  {
    id: 6,
    title: "Time Tracker",
    description: "Gamified time management tool that makes scheduling and task completion fun",
    difficulty: "Medium",
    duration: "Ongoing",
    category: "Organization",
    icon: Clock,
    color: "bg-orange-100 text-orange-600",
    available: false,
  },
]

const getDifficultyColor = (difficulty: string) => {
  switch (difficulty) {
    case "Easy":
      return "bg-green-100 text-green-800"
    case "Medium":
      return "bg-yellow-100 text-yellow-800"
    case "Hard":
      return "bg-red-100 text-red-800"
    default:
      return "bg-gray-100 text-gray-800"
  }
}

export default function GamesPage() {
  const [currentGame, setCurrentGame] = useState<string | null>(null)

  const handlePlayGame = (gameId: number) => {
    const game = games.find((g) => g.id === gameId)
    if (game?.available) {
      setCurrentGame(game.title)
    }
  }

  const handleBackToGames = () => {
    setCurrentGame(null)
  }

  if (currentGame === "Focus Flow") {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background via-card/30 to-secondary/20">
        <Navigation />
        <main className="container mx-auto px-4 py-12">
          <FocusFlow onBack={handleBackToGames} />
        </main>
      </div>
    )
  }

  if (currentGame === "Memory Garden") {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background via-card/30 to-secondary/20">
        <Navigation />
        <main className="container mx-auto px-4 py-12">
          <MemoryGarden onBack={handleBackToGames} />
        </main>
      </div>
    )
  }

  if (currentGame === "Calm Coloring") {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background via-card/30 to-secondary/20">
        <Navigation />
        <main className="container mx-auto px-4 py-12">
          <CalmColoring onBack={handleBackToGames} />
        </main>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-card/30 to-secondary/20">
      <Navigation />

      <main className="container mx-auto px-4 py-12">
        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <div className="text-center mb-12">
            <div className="h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
              <Gamepad2 className="h-8 w-8 text-primary" />
            </div>
            <h1 className="text-3xl font-bold mb-2">ADHD-Friendly Games</h1>
            <p className="text-muted-foreground text-pretty max-w-2xl mx-auto">
              Engaging mini-games designed to support focus, memory, and emotional regulation while being fun and
              stress-free
            </p>
          </div>

          {/* Benefits Section */}
          <Card className="mb-8 bg-gradient-to-r from-primary/5 to-secondary/5 border-primary/20">
            <CardHeader>
              <CardTitle className="text-center">Why Gaming Helps with ADHD</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-3 gap-4 text-center">
                <div>
                  <Brain className="h-8 w-8 text-primary mx-auto mb-2" />
                  <h3 className="font-semibold mb-1">Cognitive Training</h3>
                  <p className="text-sm text-muted-foreground">
                    Strengthen working memory, attention, and executive function
                  </p>
                </div>
                <div>
                  <Target className="h-8 w-8 text-secondary mx-auto mb-2" />
                  <h3 className="font-semibold mb-1">Focus Practice</h3>
                  <p className="text-sm text-muted-foreground">Build sustained attention skills in an engaging way</p>
                </div>
                <div>
                  <Star className="h-8 w-8 text-accent mx-auto mb-2" />
                  <h3 className="font-semibold mb-1">Stress Relief</h3>
                  <p className="text-sm text-muted-foreground">
                    Provide calming, enjoyable activities for emotional regulation
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Games Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {games.map((game) => {
              const Icon = game.icon

              return (
                <Card
                  key={game.id}
                  className="group hover:shadow-lg transition-all duration-300 hover:-translate-y-1 border-primary/10"
                >
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className={`h-12 w-12 rounded-lg ${game.color} flex items-center justify-center mb-3`}>
                        <Icon className="h-6 w-6" />
                      </div>
                      {!game.available && <Lock className="h-4 w-4 text-muted-foreground" />}
                    </div>
                    <CardTitle className="text-lg">{game.title}</CardTitle>
                    <CardDescription className="text-sm leading-relaxed">{game.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex flex-wrap gap-2 mb-4">
                      <Badge variant="secondary" className="text-xs">
                        {game.category}
                      </Badge>
                      <Badge className={`text-xs ${getDifficultyColor(game.difficulty)}`}>{game.difficulty}</Badge>
                      <Badge variant="outline" className="text-xs">
                        <Clock className="h-3 w-3 mr-1" />
                        {game.duration}
                      </Badge>
                    </div>

                    <Button
                      className="w-full group-hover:bg-primary/90 transition-colors"
                      disabled={!game.available}
                      size="sm"
                      onClick={() => handlePlayGame(game.id)}
                    >
                      {game.available ? (
                        <>
                          <Play className="h-4 w-4 mr-2" />
                          Play Game
                        </>
                      ) : (
                        <>
                          <Lock className="h-4 w-4 mr-2" />
                          Coming Soon
                        </>
                      )}
                    </Button>
                  </CardContent>
                </Card>
              )
            })}
          </div>

          {/* Tips Section */}
          <Card className="mt-12 border-primary/20">
            <CardHeader>
              <CardTitle className="text-center">Gaming Tips for ADHD</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-3">
                  <h4 className="font-semibold text-primary">Before You Play:</h4>
                  <ul className="space-y-2 text-sm text-muted-foreground">
                    <li>• Set a timer to avoid hyperfocus</li>
                    <li>• Choose games based on your energy level</li>
                    <li>• Take breaks every 15-20 minutes</li>
                  </ul>
                </div>
                <div className="space-y-3">
                  <h4 className="font-semibold text-primary">During Play:</h4>
                  <ul className="space-y-2 text-sm text-muted-foreground">
                    <li>• Focus on progress, not perfection</li>
                    <li>• Use games as rewards for completing tasks</li>
                    <li>• Stop if you feel frustrated or overwhelmed</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
