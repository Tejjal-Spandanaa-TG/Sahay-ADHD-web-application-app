import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Navigation } from "@/components/navigation"
import { Glasses, Heart, Brain, Users, Headphones, Eye, ArrowRight, Play, Info } from "lucide-react"

const vrExperiences = [
  {
    id: 1,
    title: "ADHD Empathy Mode",
    description:
      "Experience what it's like to have ADHD through immersive simulations that help others understand the challenges and strengths of neurodivergent minds.",
    features: [
      "Attention simulation scenarios",
      "Sensory processing experiences",
      "Executive function challenges",
      "Hyperfocus demonstration",
    ],
    duration: "15-30 minutes",
    audience: "Family, Friends, Educators",
    icon: Heart,
    color: "bg-pink-100 text-pink-600",
    available: false,
  },
  {
    id: 2,
    title: "ADHD Therapy Mode",
    description:
      "Therapeutic VR environments designed to help individuals with ADHD practice coping strategies, improve focus, and develop emotional regulation skills.",
    features: [
      "Guided meditation spaces",
      "Focus training exercises",
      "Stress reduction environments",
      "Social skills practice",
    ],
    duration: "10-45 minutes",
    audience: "Individuals with ADHD",
    icon: Brain,
    color: "bg-blue-100 text-blue-600",
    available: false,
  },
]

const benefits = [
  {
    title: "Immersive Learning",
    description: "VR provides distraction-free environments that can help with focus and engagement",
    icon: Eye,
  },
  {
    title: "Safe Practice Space",
    description: "Practice real-world scenarios in a controlled, supportive virtual environment",
    icon: Users,
  },
  {
    title: "Sensory Regulation",
    description: "Customizable environments that can be adjusted for sensory sensitivities",
    icon: Headphones,
  },
]

export default function VRPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-card/30 to-secondary/20">
      <Navigation />

      <main className="container mx-auto px-4 py-12">
        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <div className="text-center mb-12">
            <div className="h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
              <Glasses className="h-8 w-8 text-primary" />
            </div>
            <h1 className="text-3xl font-bold mb-2">VR Experiences for ADHD</h1>
            <p className="text-muted-foreground text-pretty max-w-2xl mx-auto">
              Immersive virtual reality experiences designed to build empathy, provide therapeutic support, and create
              understanding around ADHD
            </p>
          </div>

          {/* Coming Soon Banner */}
          <Card className="mb-8 bg-gradient-to-r from-secondary/10 to-primary/10 border-primary/20">
            <CardContent className="text-center py-8">
              <Info className="h-12 w-12 text-primary mx-auto mb-4" />
              <h2 className="text-2xl font-bold mb-2">Coming Soon</h2>
              <p className="text-muted-foreground mb-4">
                We're developing cutting-edge VR experiences to support the ADHD community. Stay tuned for updates!
              </p>
              <Button variant="outline">
                <span>Get Notified</span>
                <ArrowRight className="h-4 w-4 ml-2" />
              </Button>
            </CardContent>
          </Card>

          {/* VR Experiences */}
          <div className="grid lg:grid-cols-2 gap-8 mb-12">
            {vrExperiences.map((experience) => {
              const Icon = experience.icon

              return (
                <Card key={experience.id} className="border-primary/10 hover:shadow-lg transition-all duration-300">
                  <CardHeader>
                    <div className={`h-12 w-12 rounded-lg ${experience.color} flex items-center justify-center mb-4`}>
                      <Icon className="h-6 w-6" />
                    </div>
                    <CardTitle className="text-xl">{experience.title}</CardTitle>
                    <CardDescription className="text-sm leading-relaxed">{experience.description}</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex flex-wrap gap-2">
                      <Badge variant="secondary" className="text-xs">
                        {experience.duration}
                      </Badge>
                      <Badge variant="outline" className="text-xs">
                        {experience.audience}
                      </Badge>
                    </div>

                    <div>
                      <h4 className="font-semibold text-sm mb-2">Key Features:</h4>
                      <ul className="space-y-1">
                        {experience.features.map((feature, index) => (
                          <li key={index} className="text-sm text-muted-foreground flex items-center">
                            <div className="h-1.5 w-1.5 rounded-full bg-primary mr-2 flex-shrink-0" />
                            {feature}
                          </li>
                        ))}
                      </ul>
                    </div>

                    <Button className="w-full" disabled>
                      <Play className="h-4 w-4 mr-2" />
                      Coming Soon
                    </Button>
                  </CardContent>
                </Card>
              )
            })}
          </div>

          {/* Benefits Section */}
          <Card className="mb-8 border-primary/20">
            <CardHeader>
              <CardTitle className="text-center">Why VR for ADHD?</CardTitle>
              <CardDescription className="text-center">
                Virtual reality offers unique advantages for neurodivergent individuals
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-3 gap-6">
                {benefits.map((benefit, index) => {
                  const Icon = benefit.icon

                  return (
                    <div key={index} className="text-center">
                      <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center mx-auto mb-3">
                        <Icon className="h-6 w-6 text-primary" />
                      </div>
                      <h3 className="font-semibold mb-2">{benefit.title}</h3>
                      <p className="text-sm text-muted-foreground leading-relaxed">{benefit.description}</p>
                    </div>
                  )
                })}
              </div>
            </CardContent>
          </Card>

          {/* Research Section */}
          <Card className="border-primary/20">
            <CardHeader>
              <CardTitle>The Science Behind VR and ADHD</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-sm text-muted-foreground leading-relaxed">
                Research shows that virtual reality can be particularly beneficial for individuals with ADHD by
                providing:
              </p>
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-semibold text-primary mb-2">Therapeutic Benefits:</h4>
                  <ul className="space-y-1 text-sm text-muted-foreground">
                    <li>• Enhanced attention training</li>
                    <li>• Reduced distractibility in controlled environments</li>
                    <li>• Improved emotional regulation skills</li>
                    <li>• Safe practice for social situations</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-semibold text-primary mb-2">Empathy Building:</h4>
                  <ul className="space-y-1 text-sm text-muted-foreground">
                    <li>• First-person ADHD experience simulations</li>
                    <li>• Educational tools for families and educators</li>
                    <li>• Reduced stigma through understanding</li>
                    <li>• Improved support systems</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
