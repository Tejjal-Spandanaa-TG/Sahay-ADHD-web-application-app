"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowLeft, Palette, RotateCcw, Download } from "lucide-react"

interface CalmColoringProps {
  onBack: () => void
}

const colors = [
  "#FF6B6B",
  "#4ECDC4",
  "#45B7D1",
  "#96CEB4",
  "#FFEAA7",
  "#DDA0DD",
  "#98D8C8",
  "#F7DC6F",
  "#BB8FCE",
  "#85C1E9",
]

export function CalmColoring({ onBack }: CalmColoringProps) {
  const [selectedColor, setSelectedColor] = useState(colors[0])
  const [isDrawing, setIsDrawing] = useState(false)
  const canvasRef = useRef<HTMLCanvasElement>(null)

  const startDrawing = (e: React.MouseEvent<HTMLCanvasElement>) => {
    setIsDrawing(true)
    draw(e)
  }

  const draw = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDrawing) return

    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const rect = canvas.getBoundingClientRect()
    const x = e.clientX - rect.left
    const y = e.clientY - rect.top

    ctx.fillStyle = selectedColor
    ctx.beginPath()
    ctx.arc(x, y, 8, 0, 2 * Math.PI)
    ctx.fill()
  }

  const stopDrawing = () => {
    setIsDrawing(false)
  }

  const clearCanvas = () => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    ctx.clearRect(0, 0, canvas.width, canvas.height)
    drawTemplate(ctx)
  }

  const drawTemplate = (ctx: CanvasRenderingContext2D) => {
    ctx.strokeStyle = "#E5E7EB"
    ctx.lineWidth = 2

    // Draw a simple mandala-like pattern
    const centerX = 200
    const centerY = 150

    // Outer circle
    ctx.beginPath()
    ctx.arc(centerX, centerY, 100, 0, 2 * Math.PI)
    ctx.stroke()

    // Inner circles
    for (let i = 0; i < 8; i++) {
      const angle = (i * Math.PI) / 4
      const x = centerX + Math.cos(angle) * 60
      const y = centerY + Math.sin(angle) * 60

      ctx.beginPath()
      ctx.arc(x, y, 25, 0, 2 * Math.PI)
      ctx.stroke()
    }

    // Center circle
    ctx.beginPath()
    ctx.arc(centerX, centerY, 30, 0, 2 * Math.PI)
    ctx.stroke()

    // Decorative lines
    for (let i = 0; i < 16; i++) {
      const angle = (i * Math.PI) / 8
      const x1 = centerX + Math.cos(angle) * 30
      const y1 = centerY + Math.sin(angle) * 30
      const x2 = centerX + Math.cos(angle) * 100
      const y2 = centerY + Math.sin(angle) * 100

      ctx.beginPath()
      ctx.moveTo(x1, y1)
      ctx.lineTo(x2, y2)
      ctx.stroke()
    }
  }

  const downloadImage = () => {
    const canvas = canvasRef.current
    if (!canvas) return

    const link = document.createElement("a")
    link.download = "calm-coloring.png"
    link.href = canvas.toDataURL()
    link.click()
  }

  // Initialize canvas with template
  const initCanvas = (canvas: HTMLCanvasElement) => {
    const ctx = canvas.getContext("2d")
    if (ctx) {
      drawTemplate(ctx)
    }
  }

  return (
    <div className="max-w-4xl mx-auto">
      <div className="flex items-center mb-6">
        <Button variant="ghost" onClick={onBack} className="mr-4">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Games
        </Button>
        <h2 className="text-2xl font-bold">Calm Coloring</h2>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Canvas */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Palette className="h-5 w-5 mr-2" />
                Your Canvas
              </CardTitle>
            </CardHeader>
            <CardContent>
              <canvas
                ref={(canvas) => {
                  if (canvas) {
                    canvasRef.current = canvas
                    initCanvas(canvas)
                  }
                }}
                width={400}
                height={300}
                className="border border-gray-200 rounded-lg cursor-crosshair w-full"
                onMouseDown={startDrawing}
                onMouseMove={draw}
                onMouseUp={stopDrawing}
                onMouseLeave={stopDrawing}
              />
            </CardContent>
          </Card>
        </div>

        {/* Controls */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Color Palette</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-5 gap-2">
                {colors.map((color) => (
                  <button
                    key={color}
                    className={`w-8 h-8 rounded-full border-2 transition-all ${
                      selectedColor === color ? "border-gray-800 scale-110" : "border-gray-300"
                    }`}
                    style={{ backgroundColor: color }}
                    onClick={() => setSelectedColor(color)}
                  />
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Tools</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button onClick={clearCanvas} variant="outline" className="w-full bg-transparent">
                <RotateCcw className="h-4 w-4 mr-2" />
                Clear Canvas
              </Button>
              <Button onClick={downloadImage} className="w-full">
                <Download className="h-4 w-4 mr-2" />
                Save Artwork
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Benefits</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="text-sm text-muted-foreground space-y-2">
                <li>• Reduces stress and anxiety</li>
                <li>• Improves focus and concentration</li>
                <li>• Promotes mindfulness</li>
                <li>• Enhances creativity</li>
              </ul>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
