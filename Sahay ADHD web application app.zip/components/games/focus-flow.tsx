"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { ArrowLeft, Play, Pause, RotateCcw } from "lucide-react"

interface FocusFlowProps {
  onBack: () => void
}

export function FocusFlow({ onBack }: FocusFlowProps) {
  const [isPlaying, setIsPlaying] = useState(false)
  const [phase, setPhase] = useState<"inhale" | "hold" | "exhale">("inhale")
  const [progress, setProgress] = useState(0)
  const [cycle, setCycle] = useState(0)
  const [totalCycles] = useState(5)

  const phaseDurations = {
    inhale: 4000,
    hold: 4000,
    exhale: 6000,
  }

  useEffect(() => {
    if (!isPlaying) return

    const duration = phaseDurations[phase]
    const interval = setInterval(() => {
      setProgress((prev) => {
        const newProgress = prev + 100 / (duration / 100)
        if (newProgress >= 100) {
          // Move to next phase
          if (phase === "inhale") {
            setPhase("hold")
          } else if (phase === "hold") {
            setPhase("exhale")
          } else {
            setPhase("inhale")
            setCycle((prev) => prev + 1)
          }
          return 0
        }
        return newProgress
      })
    }, 100)

    return () => clearInterval(interval)
  }, [isPlaying, phase])

  useEffect(() => {
    if (cycle >= totalCycles) {
      setIsPlaying(false)
      setPhase("inhale")
      setProgress(0)
    }
  }, [cycle, totalCycles])

  const handleReset = () => {
    setIsPlaying(false)
    setPhase("inhale")
    setProgress(0)
    setCycle(0)
  }

  const getPhaseInstruction = () => {
    switch (phase) {
      case "inhale":
        return "Breathe In"
      case "hold":
        return "Hold"
      case "exhale":
        return "Breathe Out"
    }
  }

  const getPhaseColor = () => {
    switch (phase) {
      case "inhale":
        return "from-blue-400 to-blue-600"
      case "hold":
        return "from-purple-400 to-purple-600"
      case "exhale":
        return "from-green-400 to-green-600"
    }
  }

  return (
    <div className="max-w-2xl mx-auto">
      <div className="flex items-center mb-6">
        <Button variant="ghost" onClick={onBack} className="mr-4">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Games
        </Button>
        <h2 className="text-2xl font-bold">Focus Flow</h2>
      </div>

      <Card className="text-center">
        <CardHeader>
          <CardTitle>Breathing Exercise</CardTitle>
          <p className="text-muted-foreground">Follow the breathing pattern to improve focus and reduce anxiety</p>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Breathing Circle */}
          <div className="relative mx-auto w-64 h-64 flex items-center justify-center">
            <div
              className={`absolute inset-0 rounded-full bg-gradient-to-br ${getPhaseColor()} transition-all duration-1000 ${
                isPlaying ? "scale-100 opacity-80" : "scale-75 opacity-40"
              }`}
              style={{
                transform: `scale(${isPlaying ? 0.8 + (progress / 500) : 0.75})`,
              }}
            />
            <div className="relative z-10 text-white font-bold text-xl">{getPhaseInstruction()}</div>
          </div>

          {/* Progress */}
          <div className="space-y-2">
            <div className="flex justify-between text-sm text-muted-foreground">
              <span>
                Cycle {cycle + 1} of {totalCycles}
              </span>
              <span>{Math.round(progress)}%</span>
            </div>
            <Progress value={progress} className="h-2" />
          </div>

          {/* Controls */}
          <div className="flex justify-center space-x-4">
            <Button
              onClick={() => setIsPlaying(!isPlaying)}
              disabled={cycle >= totalCycles}
              className="flex items-center space-x-2"
            >
              {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
              <span>{isPlaying ? "Pause" : "Start"}</span>
            </Button>
            <Button variant="outline" onClick={handleReset}>
              <RotateCcw className="h-4 w-4 mr-2" />
              Reset
            </Button>
          </div>

          {cycle >= totalCycles && (
            <div className="bg-green-50 border border-green-200 rounded-lg p-4">
              <p className="text-green-800 font-medium">Great job! You've completed the breathing exercise.</p>
              <p className="text-green-600 text-sm mt-1">
                Take a moment to notice how you feel. Regular breathing exercises can help improve focus and reduce
                stress.
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
