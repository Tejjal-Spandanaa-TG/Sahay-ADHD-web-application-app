"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowLeft, Flower, Flower2, TreePine, Sprout } from "lucide-react"

interface MemoryGardenProps {
  onBack: () => void
}

const plants = [
  { id: 1, icon: Flower, name: "Rose", color: "text-red-500" },
  { id: 2, icon: Flower2, name: "Tulip", color: "text-yellow-500" },
  { id: 3, icon: TreePine, name: "Pine", color: "text-green-600" },
  { id: 4, icon: Sprout, name: "Sprout", color: "text-green-400" },
]

export function MemoryGarden({ onBack }: MemoryGardenProps) {
  const [sequence, setSequence] = useState<number[]>([])
  const [playerSequence, setPlayerSequence] = useState<number[]>([])
  const [isShowing, setIsShowing] = useState(false)
  const [gameState, setGameState] = useState<"waiting" | "showing" | "playing" | "correct" | "wrong">("waiting")
  const [level, setLevel] = useState(1)
  const [score, setScore] = useState(0)
  const [highlightedPlant, setHighlightedPlant] = useState<number | null>(null)

  const startGame = () => {
    const newSequence = Array.from({ length: level + 2 }, () => Math.floor(Math.random() * 4))
    setSequence(newSequence)
    setPlayerSequence([])
    setGameState("showing")
    setIsShowing(true)
    showSequence(newSequence)
  }

  const showSequence = async (seq: number[]) => {
    for (let i = 0; i < seq.length; i++) {
      await new Promise((resolve) => setTimeout(resolve, 600))
      setHighlightedPlant(seq[i])
      await new Promise((resolve) => setTimeout(resolve, 600))
      setHighlightedPlant(null)
    }
    setIsShowing(false)
    setGameState("playing")
  }

  const handlePlantClick = (plantIndex: number) => {
    if (gameState !== "playing") return

    const newPlayerSequence = [...playerSequence, plantIndex]
    setPlayerSequence(newPlayerSequence)

    // Check if the current input is correct
    if (newPlayerSequence[newPlayerSequence.length - 1] !== sequence[newPlayerSequence.length - 1]) {
      setGameState("wrong")
      return
    }

    // Check if sequence is complete
    if (newPlayerSequence.length === sequence.length) {
      setGameState("correct")
      setScore(score + level * 10)
      setTimeout(() => {
        setLevel(level + 1)
        setGameState("waiting")
      }, 1500)
    }
  }

  const resetGame = () => {
    setLevel(1)
    setScore(0)
    setSequence([])
    setPlayerSequence([])
    setGameState("waiting")
    setHighlightedPlant(null)
  }

  return (
    <div className="max-w-2xl mx-auto">
      <div className="flex items-center mb-6">
        <Button variant="ghost" onClick={onBack} className="mr-4">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Games
        </Button>
        <h2 className="text-2xl font-bold">Memory Garden</h2>
      </div>

      <Card>
        <CardHeader className="text-center">
          <CardTitle>Plant the Sequence</CardTitle>
          <p className="text-muted-foreground">
            Watch the plants light up, then repeat the sequence to grow your garden
          </p>
          <div className="flex justify-center space-x-6 text-sm">
            <span>Level: {level}</span>
            <span>Score: {score}</span>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Garden Grid */}
          <div className="grid grid-cols-2 gap-4 max-w-md mx-auto">
            {plants.map((plant, index) => {
              const Icon = plant.icon
              const isHighlighted = highlightedPlant === index
              const isClickable = gameState === "playing"

              return (
                <Button
                  key={plant.id}
                  variant="outline"
                  className={`h-24 w-24 rounded-xl transition-all duration-300 ${
                    isHighlighted ? "bg-primary/20 border-primary scale-110" : ""
                  } ${isClickable ? "hover:scale-105" : ""}`}
                  onClick={() => handlePlantClick(index)}
                  disabled={!isClickable}
                >
                  <div className="text-center">
                    <Icon className={`h-8 w-8 mx-auto mb-1 ${plant.color}`} />
                    <span className="text-xs">{plant.name}</span>
                  </div>
                </Button>
              )
            })}
          </div>

          {/* Game Status */}
          <div className="text-center">
            {gameState === "waiting" && (
              <Button onClick={startGame} size="lg">
                Start Level {level}
              </Button>
            )}
            {gameState === "showing" && <p className="text-lg font-medium text-blue-600">Watch the sequence...</p>}
            {gameState === "playing" && (
              <p className="text-lg font-medium text-green-600">
                Your turn! ({playerSequence.length}/{sequence.length})
              </p>
            )}
            {gameState === "correct" && (
              <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                <p className="text-green-800 font-medium">Perfect! Moving to level {level + 1}</p>
              </div>
            )}
            {gameState === "wrong" && (
              <div className="bg-red-50 border border-red-200 rounded-lg p-4 space-y-3">
                <p className="text-red-800 font-medium">Oops! Try again</p>
                <div className="space-x-2">
                  <Button onClick={startGame} size="sm">
                    Retry Level
                  </Button>
                  <Button onClick={resetGame} variant="outline" size="sm">
                    Start Over
                  </Button>
                </div>
              </div>
            )}
          </div>

          {/* Instructions */}
          <div className="bg-muted/50 rounded-lg p-4 text-sm text-center">
            <p className="text-muted-foreground">
              This game helps improve working memory by challenging you to remember and repeat sequences. Each level
              adds more plants to remember!
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
